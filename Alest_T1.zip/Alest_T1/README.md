# Trabalho T1 - ALEST1

Utilização de Listas Lineares Estáticas e comparação de diferentes algoritmos de ordenação
