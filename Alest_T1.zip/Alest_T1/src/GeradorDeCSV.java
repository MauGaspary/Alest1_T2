import classesdeapoio.ListaMercadorias;
import classesdeapoio.arquivosaida.ArquivoSaida;
import classesdeapoio.arquivosaida.LinhaArquivoSaida;
import classesdeapoio.ordenacao.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Comparator;

public class GeradorDeCSV {
    public static void main(String[] args) {
        ListaMercadorias lista = new ListaMercadorias();

        File[] arquivos;
        File diretorio = new File("alest1-202301-Trabalho-01\\arquivos");
        arquivos = diretorio.listFiles();

        Arrays.sort(arquivos, new Comparator<File>() {
            @Override
            public int compare(File file1, File file2) {
                String nome1 = file1.getName();
                String nome2 = file2.getName();
                String numStr1 = nome1.replaceAll("\\D+", ""); // Remove tudo que não é dígito
                String numStr2 = nome2.replaceAll("\\D+", ""); // Remove tudo que não é dígito
                int num1 = Integer.parseInt(numStr1);
                int num2 = Integer.parseInt(numStr2);
                return Integer.compare(num1, num2);
            }
        });

        ArquivoSaida relatorioSaida = new ArquivoSaida("relatorio.csv");

        for (int p = 0; p < arquivos.length; p++) {
            String arquivo = arquivos[p].getAbsolutePath();

            try {
                lista.carregarArquivo(arquivo);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }

            System.out.println("Arquivo " + arquivo + " carregado com sucesso.");
            System.out.println("Total de " + lista.getQuantidade() + " itens.");

            int[] arrayCodigosBS = new int[lista.getQuantidade()];
            int[] arrayCodigosBSO = new int[lista.getQuantidade()];
            int[] arrayCodigosIS = new int[lista.getQuantidade()];
            int[] arrayCodigosMS = new int[lista.getQuantidade()];
            int[] arrayCodigosQS = new int[lista.getQuantidade()];
            for (int i = 0; i < lista.getQuantidade(); i++) {
                arrayCodigosBS[i] = lista.buscar(i).getCodigo();
                arrayCodigosBSO[i] = lista.buscar(i).getCodigo();
                arrayCodigosIS[i] = lista.buscar(i).getCodigo();
                arrayCodigosMS[i] = lista.buscar(i).getCodigo();
                arrayCodigosQS[i] = lista.buscar(i).getCodigo();
            }

            BubbleSort bs = new BubbleSort();
            bs.ordenar(arrayCodigosBS);

            BubbleSortOtimizado bso = new BubbleSortOtimizado();
            bso.ordenar(arrayCodigosBSO);

            InsertionSort is = new InsertionSort();
            is.ordenar(arrayCodigosIS);

            MergeSort ms = new MergeSort();
            ms.ordenar(arrayCodigosMS);

            QuickSort qs = new QuickSort();
            qs.ordenar(arrayCodigosQS);

            LinhaArquivoSaida a = new LinhaArquivoSaida(lista.getQuantidade(),bs.getTempoExecucao(),bs.getOperacoes(),bso.getTempoExecucao(),bso.getOperacoes(),is.getTempoExecucao(),is.getOperacoes(),ms.getTempoExecucao(),ms.getOperacoes(),qs.getTempoExecucao(),qs.getOperacoes());
            relatorioSaida.adicionarLinha(a);
        }

        relatorioSaida.salvar();
    }
}
